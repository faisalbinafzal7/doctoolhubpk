import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Shield, Zap, Globe, Heart, Users, Target, CheckCircle2, Mail, ShieldCheck, Cpu } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

export default function About() {
  const stats = [
    { label: 'Free Utilities', value: '40+', icon: Zap },
    { label: 'Privacy Focused', value: '100%', icon: ShieldCheck },
    { label: 'Monthly Users', value: '10k+', icon: Users },
    { label: 'Uptime', value: '99.9%', icon: Cpu },
  ];

  return (
    <div className="pb-20">
      <Helmet>
        <title>About Us - DocToolHubPK | Our Mission & Privacy Commitment</title>
        <meta name="description" content="Discover the mission behind DocToolHubPK. We provide 40+ professional, browser-based tools with 100% data privacy and lightning-fast performance." />
        <link rel="canonical" href="https://doctoolhubpk.com/about" />
      </Helmet>

      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-slate-900 pt-20 pb-32">
        {/* Background Patterns */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center px-4 py-1.5 rounded-full bg-sky-500/10 border border-sky-400/20 text-sky-400 text-xs font-black uppercase tracking-[0.2em] mb-6">
              Our Story
            </span>
            <h1 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tight">
              Empowering the Web with <span className="text-sky-400 italic">Privacy-First</span> Tools.
            </h1>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed">
              DocToolHubPK was founded on a simple belief: the tools you use to handle your most sensitive documents and data should never be a security risk.
            </p>
          </motion.div>
        </div>
      </section>

      {/* STATS STRIP */}
      <div className="max-w-7xl mx-auto px-4 -mt-16 relative z-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-xl shadow-slate-900/5 text-center transition-all hover:border-sky-500"
            >
              <div className="w-12 h-12 bg-sky-50 text-sky-500 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-sky-100">
                <stat.icon className="w-6 h-6" />
              </div>
              <div className="text-2xl font-black text-slate-900 mb-1">{stat.value}</div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* MISSION SECTION */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-2 h-8 bg-sky-500 rounded-full" />
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Our Mission</h2>
            </div>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed font-medium">
              <p>
                In an era where massive cloud platforms often prioritize data collection over user security, <strong className="text-slate-900">DocToolHubPK stands firmly on the side of the individual.</strong>
              </p>
              <p>
                Our mission is to provide a "Swiss Army Knife" of productivity utilities that operate entirely within your browser. By leveraging modern client-side technologies like <strong className="text-sky-500">WebAssembly</strong> and <strong className="text-sky-500">Next-gen JavaScript</strong>, we ensure that your files never touch a remote server.
              </p>
              <p>
                Whether you're merging a confidential contract, compressing a family photo, or formatting sensitive code, you can do so with the absolute certainty that your data remains yours and yours alone.
              </p>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-slate-50 p-8 md:p-12 rounded-[3rem] border border-slate-200 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-sky-500/5 rounded-full -mr-32 -mt-32 transition-all group-hover:scale-110" />
            <h3 className="text-2xl font-black text-slate-900 mb-8 relative z-10">The Core Values That Drive Us</h3>
            <div className="space-y-8 relative z-10">
              <div className="flex items-start space-x-4">
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 shrink-0">
                  <Shield className="w-6 h-6 text-sky-500" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-slate-900">100% Privacy</h4>
                  <p className="text-slate-500 text-sm">No uploads. No storage. No risks. Your browser is your sandbox.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 shrink-0">
                  <Target className="w-6 h-6 text-sky-500" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-slate-900">Human-Centric Design</h4>
                  <p className="text-slate-500 text-sm">We build tools that are intuitive, fast, and accessible to everyone.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 shrink-0">
                  <Globe className="w-6 h-6 text-sky-500" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-slate-900">Free & Unrestricted</h4>
                  <p className="text-slate-500 text-sm">No hidden walls. No subscriptions. Premium tools for the open web.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* THE TEAM */}
      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex flex-col items-center mb-16">
            <Heart className="w-10 h-10 text-red-500 mb-4 animate-bounce" />
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Built by Makers, for Everyone</h2>
            <p className="text-slate-500 max-w-2xl mt-4 font-medium">
              DocToolHubPK is a labor of love from a small, dedicated team of developers. We're on a journey to build the internet's most trusted utility hub.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Security First', desc: 'Every line of code is written with a focus on client-side safety.' },
              { title: 'Community Driven', desc: 'We add new tools every week based on user suggestions.' },
              { title: 'Global Reach', desc: 'Accessible in over 150 countries, optimized for all devices.' },
            ].map((feature, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1"
              >
                <CheckCircle2 className="w-8 h-8 text-sky-500 mx-auto mb-4" />
                <h3 className="text-xl font-black text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-500 text-sm font-medium">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="pt-24 max-w-5xl mx-auto px-4 text-center">
        <div className="bg-sky-500 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden shadow-2xl shadow-sky-500/20">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -ml-32 -mt-32 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-black/10 rounded-full -mr-32 -mb-32 blur-3xl" />
          
          <h2 className="text-3xl md:text-5xl font-black mb-8 relative z-10 leading-tight">
            Ready to experience a <br />better way of working?
          </h2>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
            <Link 
              to="/all-tools" 
              className="bg-white text-sky-500 px-10 py-4 rounded-2xl font-black text-lg hover:scale-105 transition-all shadow-xl shadow-sky-900/20"
            >
              Explore 40+ Tools
            </Link>
            <a 
              href="mailto:info@doctoolhubpk.com" 
              className="flex items-center px-10 py-4 rounded-2xl font-black text-lg bg-sky-600/50 hover:bg-sky-600 transition-all border border-white/20"
            >
              <Mail className="w-5 h-5 mr-3" /> Get in Touch
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
