import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Home, Search, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <Helmet>
        <title>404 - Page Not Found | DocToolHubPK</title>
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      
      <div className="max-w-md w-full text-center space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="relative">
          <h1 className="text-9xl font-black text-slate-100">404</h1>
          <div className="absolute inset-0 flex items-center justify-center">
            <h2 className="text-3xl font-bold text-slate-900">Oops! Page Missing</h2>
          </div>
        </div>
        
        <p className="text-slate-600 text-lg">
          The page you're looking for was moved, renamed, or might never have existed. 
          Use our professional tools instead!
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/"
            className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-200"
          >
            <Home className="w-5 h-5" />
            Back to Home
          </Link>
          <Link
            to="/all-tools"
            className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            <Search className="w-5 h-5" />
            Browse Tools
          </Link>
        </div>
        
        <div className="pt-8 border-t border-slate-100">
          <p className="text-sm text-slate-400">
            Need help? <Link to="/contact" className="text-blue-500 hover:underline">Contact Support</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
