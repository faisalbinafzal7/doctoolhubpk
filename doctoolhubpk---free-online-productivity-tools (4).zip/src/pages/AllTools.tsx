import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Search, ArrowRight } from 'lucide-react';
import { TOOLS, categories } from '@/src/data/tools';
import { motion } from 'motion/react';
import { ToolCard } from '../components/ToolCard';

export default function AllTools() {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState<string | null>(null);

  const filteredTools = React.useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    
    let results = TOOLS.filter(tool => {
      const matchesCategory = selectedCategory ? tool.category === selectedCategory : true;
      if (!q) return matchesCategory;

      const matchesSearch = 
        tool.name.toLowerCase().includes(q) ||
        tool.shortDescription.toLowerCase().includes(q) ||
        (tool.description && tool.description.toLowerCase().includes(q)) ||
        (tool.keyword && tool.keyword.toLowerCase().includes(q)) ||
        (tool.tags && tool.tags.some(tag => tag.toLowerCase().includes(q))) ||
        tool.slug.toLowerCase().includes(q);

      return matchesSearch && matchesCategory;
    });

    if (q) {
      results = [...results].sort((a, b) => {
        const aName = a.name.toLowerCase();
        const bName = b.name.toLowerCase();
        
        // Exact name match priority
        if (aName === q && bName !== q) return -1;
        if (bName === q && aName !== q) return 1;
        
        // Name starts with query priority
        const aStarts = aName.startsWith(q) ? 2 : (aName.includes(q) ? 1 : 0);
        const bStarts = bName.startsWith(q) ? 2 : (bName.includes(q) ? 1 : 0);
        
        if (aStarts !== bStarts) return bStarts - aStarts;

        // Usage count as tie-breaker
        return (b.usageCount || 0) - (a.usageCount || 0);
      });
    }

    return results;
  }, [searchQuery, selectedCategory]);

  return (
    <div className="pb-20">
      <Helmet>
        <title>All Tools - Explore Our Ultimate Free Online Tools Hub | DocToolHubPK</title>
        <meta name="description" content="Discover DocToolHubPK, your all-in-one platform for image tools, PDF converters, SEO utilities, and developer tools. Completely free, fast, and easy to use—designed to simplify your daily tasks and boost productivity with 100% privacy." />
        <link rel="canonical" href="https://doctoolhubpk.com/all-tools" />
      </Helmet>

      <section className="bg-white border-b border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">All Productivity Tools</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10">
            Browse our complete directory of free, secure, and browser-based utilities.
          </p>

          <div className="max-w-2xl mx-auto relative mb-12">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-6 h-6" />
            <input
              type="text"
              placeholder="Search through all 40+ tools..."
              className="w-full pl-12 pr-4 py-4 bg-white border-2 border-slate-200 rounded-2xl focus:border-sky-400 focus:outline-none transition-all shadow-sm text-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Category Filter Chips */}
          <div className="flex flex-wrap justify-center gap-3 max-w-5xl mx-auto">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all border shadow-sm ${
                selectedCategory === null 
                  ? 'bg-slate-900 border-slate-900 text-white' 
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              All Tools
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all flex items-center space-x-2 border shadow-sm ${
                  selectedCategory === category.id 
                    ? 'bg-sky-500 border-sky-400 text-white' 
                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <category.icon className={`w-4 h-4 ${selectedCategory === category.id ? 'text-white' : 'text-sky-500'}`} />
                <span>{category.name}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 pb-6 border-b border-slate-200/60 gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-2 h-8 bg-sky-500 rounded-full" />
            <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
              {selectedCategory 
                ? categories.find(c => c.id === selectedCategory)?.name 
                : 'All Utility Tools'}
            </h2>
          </div>
          <p className="text-slate-500 font-bold bg-white px-5 py-2 rounded-2xl border border-slate-200 shadow-sm flex items-center">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse" />
            {filteredTools.length} total tools
          </p>
        </div>

        {selectedCategory ? (
          // If a specific category is selected, show a simple grid
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTools.length > 0 ? (
              filteredTools.map((tool, idx) => (
                <ToolCard key={tool.id} tool={tool} idx={idx} showFullDescription />
              ))
            ) : (
              <div className="col-span-full text-center py-24 bg-slate-50/50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
                <div className="bg-white w-20 h-20 rounded-full shadow-lg flex items-center justify-center mx-auto mb-6 text-slate-300">
                  <Search className="w-10 h-10" />
                </div>
                <p className="text-slate-500 font-bold text-xl mb-2">No tools found matching your search</p>
                <p className="text-slate-400 mb-8 max-w-sm mx-auto font-medium">Try adjusting your filters or search keywords to find what you need.</p>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedCategory(null); }}
                  className="bg-sky-500 text-white px-8 py-3 rounded-2xl font-bold hover:bg-sky-600 transition-all shadow-lg shadow-sky-100"
                >
                  Reset all filters
                </button>
              </div>
            )}
          </div>
        ) : (
          // Default grouped view
          <div className="space-y-20">
            {categories.map((category) => {
              const categoryTools = filteredTools.filter(t => t.category === category.id);
              if (categoryTools.length === 0) return null;

              return (
                <div key={category.id}>
                  <div className="flex items-center space-x-4 mb-10 group">
                    <div className="w-12 h-12 bg-white text-sky-500 rounded-2xl flex items-center justify-center shadow-md border border-slate-100 group-hover:scale-110 transition-transform">
                      <category.icon className="w-7 h-7" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">{category.name}</h2>
                      <div className="h-0.5 w-12 bg-sky-200 mt-1 transition-all group-hover:w-full" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {categoryTools.map((tool, idx) => (
                      <ToolCard key={tool.id} tool={tool} idx={idx} showFullDescription />
                    ))}
                  </div>
                </div>
              );
            })}

            {filteredTools.length === 0 && (
              <div className="text-center py-24 bg-slate-50/50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
                <div className="bg-white w-20 h-20 rounded-full shadow-lg flex items-center justify-center mx-auto mb-6 text-slate-300">
                  <Search className="w-10 h-10" />
                </div>
                <p className="text-slate-500 font-bold text-xl mb-2">No tools found matching your search</p>
                <p className="text-slate-400 mb-8 max-w-sm mx-auto font-medium">We couldn't find anything matching your term. Try another search!</p>
                <button 
                  onClick={() => setSearchQuery('')}
                  className="bg-sky-500 text-white px-8 py-3 rounded-2xl font-bold hover:bg-sky-600 transition-all shadow-lg shadow-sky-100"
                >
                  Clear search
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* AdSense Placeholder */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="w-full h-24 bg-slate-100 border border-slate-200 rounded-lg flex items-center justify-center text-slate-400 text-sm uppercase tracking-widest">
          Advertisement
        </div>
      </div>
    </div>
  );
}
