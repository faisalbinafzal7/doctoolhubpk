import React, { useState } from 'react';
import { Calendar, Trash2, Copy, Check } from 'lucide-react';

const AgeCalculator: React.FC = () => {
  const [birthDate, setBirthDate] = useState<string>('');
  const [ageData, setAgeData] = useState<{
    years: number;
    months: number;
    days: number;
    totalDays: number;
    totalWeeks: number;
    nextBirthday: number;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  const calculateAge = () => {
    if (!birthDate) return;

    const birth = new Date(birthDate);
    const now = new Date();

    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      const prevMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      days += prevMonthLastDay;
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDays = Math.floor((now.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);

    // Next birthday
    const nextBday = new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < now) {
      nextBday.setFullYear(now.getFullYear() + 1);
    }
    const nextBirthday = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    setAgeData({
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      nextBirthday
    });
  };

  const handleCopy = () => {
    if (!ageData) return;
    const text = `${ageData.years} Years, ${ageData.months} Months, ${ageData.days} Days`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearAll = () => {
    setBirthDate('');
    setAgeData(null);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <label className="block text-sm font-medium text-slate-700 mb-2">
          Select Your Date of Birth
        </label>
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <input
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="flex-1 px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-sans"
          />
          <button
            onClick={calculateAge}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <Calendar className="w-5 h-5" />
            Calculate Age
          </button>
        </div>

        {ageData && (
          <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 text-center">
                <p className="text-blue-600 text-sm font-semibold uppercase tracking-wider mb-1">Years</p>
                <p className="text-4xl font-bold text-slate-900">{ageData.years}</p>
              </div>
              <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100 text-center">
                <p className="text-indigo-600 text-sm font-semibold uppercase tracking-wider mb-1">Months</p>
                <p className="text-4xl font-bold text-slate-900">{ageData.months}</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-xl border border-purple-100 text-center">
                <p className="text-purple-600 text-sm font-semibold uppercase tracking-wider mb-1">Days</p>
                <p className="text-4xl font-bold text-slate-900">{ageData.days}</p>
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Detailed Statistics
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <p className="text-slate-500 text-sm mb-1">Total Weeks</p>
                  <p className="text-xl font-bold text-slate-900">{ageData.totalWeeks.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-sm mb-1">Total Days</p>
                  <p className="text-xl font-bold text-slate-900">{ageData.totalDays.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-sm mb-1">Next Birthday In</p>
                  <p className="text-xl font-bold text-blue-600">{ageData.nextBirthday} Days</p>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center gap-4 pt-4 border-t border-slate-100">
              <button
                onClick={clearAll}
                className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-red-600 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                Clear
              </button>
              <button
                onClick={handleCopy}
                className={`flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-all ${
                  copied ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copied!' : 'Copy Summary'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AgeCalculator;
