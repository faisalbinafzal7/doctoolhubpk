import React, { useState } from 'react';
import { AlignLeft, Copy, Check, RefreshCw } from 'lucide-react';

const LOREM_DATA = [
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
  "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
  "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.",
  "Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.",
  "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.",
  "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.",
  "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque.",
  "Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio."
];

const LoremIpsumGenerator: React.FC = () => {
  const [paragraphs, setParagraphs] = useState<number>(3);
  const [generatedText, setGeneratedText] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const generateLorem = () => {
    let result = [];
    for (let i = 0; i < paragraphs; i++) {
      const p = LOREM_DATA.slice().sort(() => Math.random() - 0.5).join(' ');
      result.push(p);
    }
    setGeneratedText(result.join('\n\n'));
  };

  const handleCopy = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row items-end gap-4 mb-6">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Number of Paragraphs
            </label>
            <input
              type="number"
              min="1"
              max="20"
              value={paragraphs}
              onChange={(e) => setParagraphs(Number(e.target.value))}
              className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-sans"
            />
          </div>
          <button
            onClick={generateLorem}
            className="px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <RefreshCw className="w-4 h-4" />
            Generate Text
          </button>
        </div>

        {generatedText && (
          <div className="space-y-4 animate-in fade-in duration-500">
            <div className="relative">
              <textarea
                readOnly
                value={generatedText}
                className="w-full min-h-[300px] p-4 rounded-lg bg-slate-50 border border-slate-200 focus:outline-none font-sans text-slate-700 text-sm leading-relaxed"
              />
              <button
                onClick={handleCopy}
                className={`absolute top-4 right-4 flex items-center gap-2 px-3 py-1.5 rounded-md font-medium text-xs transition-all ${
                  copied ? 'bg-green-600 text-white shadow-md' : 'bg-white text-slate-700 border border-slate-200 shadow-sm hover:shadow-md'
                }`}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            
            <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <AlignLeft className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-blue-900">Stats</p>
                  <p className="text-xs text-blue-700">
                    {generatedText.split(' ').length} words | {generatedText.length} characters
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoremIpsumGenerator;
