import React, { useState } from 'react';
import { Palette, Check, X, Info } from 'lucide-react';

const ColorContrastChecker: React.FC = () => {
  const [fgColor, setFgColor] = useState('#000000');
  const [bgColor, setBgColor] = useState('#FFFFFF');

  const getLuminance = (hex: string) => {
    const rgb = hex.match(/[A-Za-z0-9]{2}/g)?.map(v => parseInt(v, 16) / 255) || [0, 0, 0];
    const lowc = rgb.map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
    return 0.2126 * lowc[0] + 0.7152 * lowc[1] + 0.0722 * lowc[2];
  };

  const lum1 = getLuminance(fgColor);
  const lum2 = getLuminance(bgColor);
  const contrast = (Math.max(lum1, lum2) + 0.05) / (Math.min(lum1, lum2) + 0.05);

  const getStatus = (ratio: number, size: 'normal' | 'large') => {
    if (size === 'normal') return ratio >= 4.5 ? 'Pass' : 'Fail';
    return ratio >= 3 ? 'Pass' : 'Fail';
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Foreground Color</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={fgColor}
              onChange={(e) => setFgColor(e.target.value)}
              className="w-12 h-12 p-1 rounded bg-slate-50 border border-slate-200"
            />
            <input
              type="text"
              value={fgColor}
              onChange={(e) => setFgColor(e.target.value)}
              className="flex-1 px-4 py-2 rounded-lg border border-slate-200 font-mono"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Background Color</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={bgColor}
              onChange={(e) => setBgColor(e.target.value)}
              className="w-12 h-12 p-1 rounded bg-slate-50 border border-slate-200"
            />
            <input
              type="text"
              value={bgColor}
              onChange={(e) => setBgColor(e.target.value)}
              className="flex-1 px-4 py-2 rounded-lg border border-slate-200 font-mono"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6 overflow-hidden">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Palette className="w-5 h-5 text-blue-600" />
            Preview
          </h3>
          <div 
            className="w-full min-h-[200px] rounded-lg p-8 flex flex-col items-center justify-center text-center space-y-4"
            style={{ backgroundColor: bgColor, color: fgColor }}
          >
            <h4 className="text-3xl font-bold">The quick brown fox</h4>
            <p className="text-lg">Jumps over the lazy dog</p>
            <p className="text-sm opacity-80 italic">Accessible design is good design.</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-900 mb-6">WCAG Results</h3>
          <div className="space-y-6">
            <div className="text-center pb-6 border-b border-slate-100">
              <p className="text-slate-500 text-sm mb-1 uppercase tracking-wider font-semibold">Contrast Ratio</p>
              <p className="text-5xl font-black text-slate-900">{contrast.toFixed(2)}:1</p>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-medium">Normal Text (AA)</span>
                <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${getStatus(contrast, 'normal') === 'Pass' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {getStatus(contrast, 'normal') === 'Pass' ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                  {getStatus(contrast, 'normal')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-medium">Large Text (AA)</span>
                <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${getStatus(contrast, 'large') === 'Pass' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {getStatus(contrast, 'large') === 'Pass' ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                  {getStatus(contrast, 'large')}
                </span>
              </div>
            </div>

            <div className="mt-6 flex items-start gap-2 p-3 bg-blue-50 rounded-lg text-xs text-blue-700 border border-blue-100">
              <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <p>WCAG AA requires a ratio of at least 4.5:1 for normal text and 3:1 for large text.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColorContrastChecker;
