import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { useEffect, Suspense, lazy } from 'react';
import { logPageView } from './lib/analytics';
import Layout from './components/Layout';
import { FullPageLoader } from './components/ui/LoadingSpinner';

// Lazy load pages
const Home = lazy(() => import('./pages/Home'));
const ToolPage = lazy(() => import('./pages/ToolPage'));
const CategoryPage = lazy(() => import('./pages/CategoryPage'));
const AllTools = lazy(() => import('./pages/AllTools'));
const Blog = lazy(() => import('./pages/Blog'));
const BlogPost = lazy(() => import('./pages/BlogPost'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const DashboardSettings = lazy(() => import('./pages/DashboardSettings'));
const NotFound = lazy(() => import('./pages/NotFound'));

// Legal Pages
const About = lazy(() => import('./pages/legal/About'));
const PrivacyPolicy = lazy(() => import('./pages/legal/PrivacyPolicy'));
const Contact = lazy(() => import('./pages/legal/Contact'));
const Disclaimer = lazy(() => import('./pages/legal/Disclaimer'));
const TermsAndConditions = lazy(() => import('./pages/legal/TermsAndConditions'));
const CookiePolicy = lazy(() => import('./pages/legal/CookiePolicy'));

import ProtectedRoute from './components/ProtectedRoute';

// Analytics component to track route changes
function AnalyticTracker() {
  const location = useLocation();

  useEffect(() => {
    logPageView();
  }, [location]);

  return null;
}

export default function App() {
  return (
    <HelmetProvider>
      <Router>
        <AnalyticTracker />
        <Layout>
          <Suspense fallback={<FullPageLoader />}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/tool/:slug" element={<ToolPage />} />
              <Route path="/category/:slug" element={<CategoryPage />} />
              <Route path="/all-tools" element={<AllTools />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/blog/:slug" element={<BlogPost />} />
              <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
              <Route path="/dashboard/settings" element={<ProtectedRoute><DashboardSettings /></ProtectedRoute>} />
              <Route path="/about" element={<About />} />
              <Route path="/privacy-policy" element={<PrivacyPolicy />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/disclaimer" element={<Disclaimer />} />
              <Route path="/terms-and-conditions" element={<TermsAndConditions />} />
              <Route path="/cookie-policy" element={<CookiePolicy />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </Layout>
      </Router>
    </HelmetProvider>
  );
}
