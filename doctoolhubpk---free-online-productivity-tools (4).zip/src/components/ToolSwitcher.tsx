import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronDown, ArrowRight, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { TOOLS, Tool } from '@/src/data/tools';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

export default function ToolSwitcher() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Tool[]>(TOOLS.slice(0, 6));
  const navigate = useNavigate();
  const switcherRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (query.trim() === '') {
      // Show popular/relevant tools when no query
      setResults(TOOLS.sort((a, b) => b.usageCount - a.usageCount).slice(0, 6));
    } else {
      const filtered = TOOLS.filter(tool => {
        const q = query.toLowerCase();
        return (
          tool.name.toLowerCase().includes(q) ||
          tool.shortDescription.toLowerCase().includes(q) ||
          (tool.tags && tool.tags.some(tag => tag.toLowerCase().includes(q)))
        );
      }).slice(0, 8);
      setResults(filtered);
    }
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (switcherRef.current && !switcherRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (slug: string) => {
    navigate(`/tool/${slug}`);
    setIsOpen(false);
    setQuery('');
  };

  return (
    <div className="relative" ref={switcherRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 hover:border-sky-500 hover:text-sky-500 transition-all shadow-sm active:scale-95"
      >
        <Zap className="w-4 h-4 text-sky-500" />
        <span>Switch Tool</span>
        <ChevronDown className={cn("w-4 h-4 transition-transform", isOpen ? "rotate-180" : "")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute top-full mt-2 left-0 md:left-auto md:right-0 w-[320px] bg-white border border-slate-200 rounded-2xl shadow-2xl z-[100] overflow-hidden"
          >
            <div className="p-4 border-b border-slate-100">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  autoFocus
                  type="text"
                  placeholder="Find another tool..."
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition-all"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="max-h-[360px] overflow-y-auto p-2">
              <p className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                {query ? 'Search Results' : 'Recommended Tools'}
              </p>
              
              {results.length > 0 ? (
                <div className="space-y-1">
                  {results.map((tool) => (
                    <button
                      key={tool.id}
                      onClick={() => handleSelect(tool.slug)}
                      className="w-full flex items-center p-2.5 rounded-xl hover:bg-sky-50 group transition-colors text-left"
                    >
                      <div className="w-9 h-9 bg-slate-100 text-slate-500 rounded-lg flex items-center justify-center mr-3 group-hover:bg-sky-500 group-hover:text-white transition-colors">
                        <tool.icon className="w-5 h-5" />
                      </div>
                      <div className="flex-grow">
                        <h4 className="text-sm font-bold text-slate-900 group-hover:text-sky-600 transition-colors">
                          {tool.name}
                        </h4>
                        <p className="text-[10px] text-slate-500 line-clamp-1">
                          {tool.shortDescription}
                        </p>
                      </div>
                      <ArrowRight className="w-3 h-3 text-slate-300 group-hover:text-sky-500 transition-all" />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center">
                  <p className="text-xs text-slate-500">No tools found matching your search</p>
                </div>
              )}
            </div>

            <div className="bg-slate-50 p-3 flex justify-center border-t border-slate-100">
              <button 
                onClick={() => { navigate('/all-tools'); setIsOpen(false); }}
                className="text-xs font-bold text-sky-500 hover:text-sky-600 uppercase tracking-wider"
              >
                Browse All 40+ Tools
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
