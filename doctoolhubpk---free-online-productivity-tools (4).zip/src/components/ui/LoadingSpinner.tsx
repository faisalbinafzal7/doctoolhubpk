import React from 'react';
import { Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

const LoadingSpinner = () => {
  return (
    <div className="flex flex-col items-center justify-center p-8">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        className="text-sky-500"
      >
        <Loader2 className="w-12 h-12" />
      </motion.div>
      <p className="mt-4 text-slate-500 font-medium animate-pulse">Loading DocToolHubPK...</p>
    </div>
  );
};

export const FullPageLoader = () => {
  return (
    <div className="fixed inset-0 bg-slate-50/80 backdrop-blur-sm z-[9999] flex items-center justify-center">
      <div className="bg-white p-8 rounded-3xl shadow-2xl shadow-sky-100 border border-slate-100">
        <LoadingSpinner />
      </div>
    </div>
  );
};

export default LoadingSpinner;
