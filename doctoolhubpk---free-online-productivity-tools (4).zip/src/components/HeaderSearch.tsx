import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, Zap, Target, FileText, Code, RefreshCw, Image as ImageIcon, Type } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { TOOLS, categories } from '@/src/data/tools';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

export default function HeaderSearch({ mobile = false }: { mobile?: boolean }) {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(TOOLS.slice(0, 5));
  const navigate = useNavigate();
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (query.trim() === '') {
      setResults(TOOLS.sort((a, b) => b.usageCount - a.usageCount).slice(0, 5));
    } else {
      const q = query.toLowerCase().trim();
      const filtered = TOOLS.filter(tool => {
        const categoryName = categories.find(c => c.id === tool.category)?.name.toLowerCase() || '';
        return (
          tool.name.toLowerCase().includes(q) ||
          tool.shortDescription.toLowerCase().includes(q) ||
          tool.slug.toLowerCase().includes(q) ||
          (tool.keyword && tool.keyword.toLowerCase().includes(q)) ||
          (tool.tags && tool.tags.some(tag => tag.toLowerCase().includes(q))) ||
          categoryName.includes(q)
        );
      }).sort((a, b) => {
        // Boost matches in title
        const aTitleMatch = a.name.toLowerCase().startsWith(q) ? 2 : (a.name.toLowerCase().includes(q) ? 1 : 0);
        const bTitleMatch = b.name.toLowerCase().startsWith(q) ? 2 : (b.name.toLowerCase().includes(q) ? 1 : 0);
        return bTitleMatch - aTitleMatch;
      }).slice(0, 8);
      setResults(filtered);
    }
  }, [query]);

  // Close search on escape or click outside
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
      if (e.key === '/' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsOpen(true);
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('mousedown', handleClickOutside);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSelect = (slug: string) => {
    navigate(`/tool/${slug}`);
    setIsOpen(false);
    setQuery('');
  };

  const getCategoryColor = (catId: string) => {
    switch (catId) {
      case 'text-tools': return 'text-amber-500 bg-amber-50';
      case 'image-tools': return 'text-purple-500 bg-purple-50';
      case 'pdf-tools': return 'text-red-500 bg-red-50';
      case 'developer-tools': return 'text-sky-500 bg-sky-50';
      case 'seo-tools': return 'text-green-500 bg-green-50';
      case 'converter-tools': return 'text-indigo-500 bg-indigo-50';
      default: return 'text-slate-500 bg-slate-50';
    }
  };

  return (
    <div 
      className={cn(
        "relative flex-grow mx-4 transition-all duration-300",
        mobile ? "w-full mx-0" : "max-w-md hidden md:block"
      )} 
      ref={searchRef}
    >
      <div 
        className={cn(
          "relative group transition-all duration-300",
          isOpen ? "ring-2 ring-sky-500 rounded-2xl shadow-lg ring-offset-2" : ""
        )}
      >
        <Search className={cn("absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors", isOpen ? "text-sky-500" : "text-slate-400")} />
        <input
          type="text"
          placeholder={mobile ? "Find a productivity tool..." : "Search 40+ tools... (Ctrl + /)"}
          className={cn(
            "w-full pl-11 pr-10 py-2.5 bg-slate-100 border border-slate-200/50 rounded-2xl text-sm font-medium focus:bg-white focus:outline-none transition-all",
            isOpen ? "border-sky-200" : ""
          )}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(true)}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center space-x-1">
          {query && (
            <button 
              onClick={() => setQuery('')}
              className="p-1 hover:bg-slate-200 rounded-full transition-colors"
            >
              <X className="w-3.5 h-3.5 text-slate-500" />
            </button>
          )}
          {!mobile && !isOpen && (
            <kbd className="hidden sm:inline-flex items-center justify-center px-1.5 py-0.5 rounded border border-slate-300 bg-white text-[10px] font-bold text-slate-400 shadow-xs pointer-events-none">
              /
            </kbd>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            className="absolute top-full mt-3 w-full bg-white border border-slate-200 rounded-[2rem] shadow-2xl z-50 overflow-hidden backdrop-blur-xl bg-white/95"
          >
            <div className="p-3">
              <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100 mb-2">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                  {query ? `Results for "${query}"` : 'Popular Utilities'}
                </p>
                {query && <span className="text-[10px] font-bold text-sky-500">{results.length} matched</span>}
              </div>
              
              {results.length > 0 ? (
                <div className="space-y-1.5 px-1 pb-2">
                  {results.map((tool) => {
                    const cat = categories.find(c => c.id === tool.category);
                    return (
                      <button
                        key={tool.id}
                        onClick={() => handleSelect(tool.slug)}
                        className="w-full flex items-center p-3 rounded-2xl hover:bg-sky-50 group transition-all text-left border border-transparent hover:border-sky-100"
                      >
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center mr-4 transition-all group-hover:scale-110 shadow-sm",
                          getCategoryColor(tool.category)
                        )}>
                          <tool.icon className="w-5 h-5" />
                        </div>
                        <div className="flex-grow min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <h4 className="text-sm font-bold text-slate-900 truncate">
                              {tool.name}
                            </h4>
                            {cat && (
                              <span className={cn(
                                "text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md leading-none",
                                getCategoryColor(tool.category)
                              )}>
                                {cat.name.replace(' Tools', '')}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 line-clamp-1 font-medium">
                            {tool.shortDescription}
                          </p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-sky-500 group-hover:translate-x-1 transition-all flex-shrink-0" />
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-12 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-dashed border-slate-200">
                    <Search className="w-6 h-6 text-slate-300" />
                  </div>
                  <p className="text-sm font-bold text-slate-600 mb-1">No tools matched your search</p>
                  <p className="text-xs text-slate-400">Try searching for keywords like "PDF", "Converter", or "SEO".</p>
                </div>
              )}
            </div>

            <div className="bg-slate-50/80 p-4 flex justify-between items-center border-t border-slate-100 backdrop-blur-sm">
              <div className="flex items-center text-[10px] text-slate-400 font-bold space-x-3">
                <span className="flex items-center"><Zap className="w-3 h-3 mr-1 text-sky-500" /> Fast Execution</span>
                <span className="flex items-center"><Target className="w-3 h-3 mr-1 text-sky-500" /> Precise Results</span>
              </div>
              <Link 
                to="/all-tools" 
                onClick={() => setIsOpen(false)}
                className="text-xs font-black text-sky-500 hover:text-sky-600 uppercase tracking-widest pl-4 border-l border-slate-200"
              >
                Browse directory
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
