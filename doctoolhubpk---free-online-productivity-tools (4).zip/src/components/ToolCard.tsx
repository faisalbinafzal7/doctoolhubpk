import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, LucideIcon, Info, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { ToolIllustration } from './ToolIllustration';

interface ToolCardProps {
  tool: {
    id: string;
    name: string;
    slug: string;
    shortDescription: string;
    description?: string;
    icon: LucideIcon;
    previewImage: string;
    externalUrl?: string;
  };
  idx?: number;
  showFullDescription?: boolean;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, idx = 0, showFullDescription: initialShowFullDescription = false }) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [isExpanded, setIsExpanded] = useState(initialShowFullDescription);

  const toggleExpand = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsExpanded(!isExpanded);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.01, y: -5 }}
      onHoverStart={() => setShowTooltip(true)}
      onHoverEnd={() => setShowTooltip(false)}
      transition={{ 
        delay: idx * 0.05,
        scale: { type: "spring", stiffness: 300, damping: 20 },
        y: { type: "spring", stiffness: 300, damping: 20 }
      }}
      className="h-full relative"
    >
      {/* Dynamic Tooltip - Only show if not already showing description in card */}
      <AnimatePresence>
        {showTooltip && tool.description && !isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute z-50 bottom-full left-0 right-0 mb-4 pointer-events-none"
          >
            <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-slate-700/50 backdrop-blur-xl relative">
              <div className="flex items-start space-x-3">
                <div className="bg-sky-500/20 p-1.5 rounded-lg shrink-0 mt-0.5">
                  <Info className="w-4 h-4 text-sky-400" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-sky-400 uppercase tracking-widest">Full Description</p>
                  <p className="text-sm text-slate-200 leading-relaxed font-medium">
                    {tool.description}
                  </p>
                </div>
              </div>
              {/* Tooltip Arrow */}
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 border-r border-b border-slate-700/50 rotate-45" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Link 
        to={tool.externalUrl || `/tool/${tool.slug}`}
        target={tool.externalUrl ? "_blank" : undefined}
        rel={tool.externalUrl ? "noopener noreferrer" : undefined}
        className="block bg-white border border-slate-200 rounded-3xl hover:border-sky-400 hover:shadow-2xl hover:shadow-sky-100/50 transition-all group h-full flex flex-col overflow-hidden"
      >
        {/* Preview Image / Icon Illustration */}
        <div className="relative h-48 overflow-hidden bg-sky-500 flex items-center justify-center">
          {tool.previewImage ? (
            <img 
              src={tool.previewImage} 
              alt={tool.name} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
          ) : (
            /* Enhanced Illustration */
            <div className="w-full h-full flex items-center justify-center relative">
              {/* Dashed Box Background */}
              <div className="absolute inset-8 border-2 border-dashed border-white/20 rounded-2xl" />
              
              {/* Corner Accents */}
              <div className="absolute top-8 left-8 w-1.5 h-1.5 bg-white/40 rounded-full" />
              <div className="absolute top-8 right-8 w-1.5 h-1.5 bg-white/40 rounded-full" />
              <div className="absolute bottom-8 left-8 w-1.5 h-1.5 bg-white/40 rounded-full" />
              <div className="absolute bottom-8 right-8 w-1.5 h-1.5 bg-white/40 rounded-full" />

              <ToolIllustration type={tool.slug} size="lg" className="relative z-10" />
            </div>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
            <div className="text-white text-xs font-bold uppercase tracking-wider flex items-center">
              Launch Tool <ArrowRight className="ml-2 w-3 h-3" />
            </div>
          </div>
        </div>

        <div className="p-6 flex flex-col flex-grow">
          <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-sky-500 transition-colors uppercase tracking-tight">{tool.name}</h3>
          <p className="text-slate-600 text-sm font-bold mb-4 leading-relaxed line-clamp-2">{tool.shortDescription}</p>
          
          {tool.description && (
            <div className="mb-4">
              <button
                onClick={toggleExpand}
                className={cn(
                  "flex items-center justify-between w-full py-2.5 px-4 rounded-xl text-sky-600 transition-all border group/expand",
                  isExpanded 
                    ? "bg-sky-50 border-sky-100" 
                    : "bg-slate-50 border-slate-100 hover:bg-sky-50 hover:border-sky-100"
                )}
              >
                <span className="text-[10px] font-black uppercase tracking-[0.15em]">
                  {isExpanded ? 'Collapse Overview' : 'Read Full Overview'}
                </span>
                <motion.div
                  animate={{ rotate: isExpanded ? 180 : 0 }}
                  className="bg-white p-1 rounded-md shadow-sm border border-slate-100 group-hover/expand:border-sky-200"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </motion.div>
              </button>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="pt-4 mt-2">
                      <div className="flex items-center space-x-2 mb-3 px-1">
                        <div className="w-1 h-3 bg-sky-500 rounded-full" />
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                          Detailed Overview
                        </p>
                      </div>
                      <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 group-hover:border-sky-100/50 group-hover:bg-white transition-all shadow-inner">
                        <p className="text-slate-600 text-sm leading-relaxed font-medium">
                          {tool.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
          
          <div className="mt-auto pt-4 flex items-center justify-between text-sky-500 font-black text-xs uppercase tracking-widest">
            <span className="flex items-center">
              Get Started <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};
